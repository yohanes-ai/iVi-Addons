# iVi - Personalized your Dashboard

**This add-on to enhance user experience while using iVi Dashboard.**

## What it does

This extension just includes:

* No set up for homepage on about:preferences

## What it shows

* Automatically full screen when start up
* Automatically create two tab on dual monitor
